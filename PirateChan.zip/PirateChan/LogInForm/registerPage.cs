﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogInForm
{
    public partial class registerPage : Form
    {
        public SqlConnection connection;
        public registerPage()
        {
            InitializeComponent();
            connection = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=pirateChanDB;Integrated Security=True;");
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string email = txtBoxEmail.Text;
            string username = txtBoxUser.Text;
            string firstName = txtBoxfirstName.Text;
            string lastName = txtBoxlastName.Text;
            string password = txtBoxPass.Text;
            string confPassword = txtBoxConfPass.Text;

            

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Please enter a valid email address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(username))
            {
                MessageBox.Show("Please enter a username.", "Invalid Username", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(firstName))
            {
                MessageBox.Show("Please enter your First Name.", "Invalid First Name", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(lastName))
            {
                MessageBox.Show("Please enter your Last Name.", "Invalid Last Name", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (password != confPassword)
            {
                MessageBox.Show("Enter matching passwords.", "Password Mismatch", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter a password.", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string encryptedPassword = EncryptPassword(password);

            string query;
            string message;

            if (rbtnAdmin.Checked)
            {
                if (IsAdminUsernameTaken(username))
                {
                    MessageBox.Show("Username is taken by another admin");
                    return;
                }

                query = "INSERT INTO ADMINISTRATOR ( A_EMAIL, A_USERNAME, A_FIRSTNAME, A_LASTNAME, A_PASSWORD) VALUES (@Email, @Username, @Firstname, @Lastname, @Password);";
                message = "Admin registration successful";
            }
            else if (rbtnCust.Checked)
            {
                if (IsCustomerUsernameTaken(username))
                {
                    MessageBox.Show("Username is taken by another customer");
                    return;
                }

                query = "INSERT INTO CUSTOMERS ( C_EMAIL, C_USERNAME, C_FIRSTNAME, C_LASTNAME, C_PASSWORD) VALUES (@Email, @Username, @Firstname, @Lastname, @Password);";
                message = "Customer registration successful";
            }
            else
            {
                MessageBox.Show("Please select user type");
                return;
            }

            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Firstname", firstName);
                command.Parameters.AddWithValue("@Lastname", lastName);
                command.Parameters.AddWithValue("@Password", encryptedPassword);
                command.ExecuteNonQuery();

                MessageBox.Show(message);
                txtBoxEmail.Clear();
                txtBoxUser.Clear();
                txtBoxfirstName.Clear();
                txtBoxlastName.Clear();
                txtBoxPass.Clear();
                txtBoxConfPass.Clear();
                chkBoxSPwd.Checked = false;
                rbtnCust.Checked = false;
                rbtnAdmin.Checked = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private string EncryptPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private bool IsValidEmail(string email)
        {
            string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            return Regex.IsMatch(email, pattern);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            loginPage login = new loginPage();
            login.ShowDialog();
            this.Close();
        }



        private void txtBoxPass_TextChanged(object sender, EventArgs e)
        {

        }

        private bool IsAdminUsernameTaken(string username)
        {
            bool isUATaken = false;

            string query = "SELECT COUNT(*) FROM ADMINISTRATOR WHERE A_USERNAME = @Username";
            connection.Open();
            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@Username", username);

            try
            {
                int count = (int)command.ExecuteScalar();
                if (count > 0)
                {
                    isUATaken = true;
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                connection.Close();
            }

            return isUATaken;
        }

        private bool IsCustomerUsernameTaken(string username)
        {
            bool isUCTaken = false;

            string query = "SELECT COUNT(*) FROM ADMINISTRATOR WHERE C_USERNAME = @Username";
            connection.Open();
            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@Username", username);

            try
            {
                int count = (int)command.ExecuteScalar();
                if (count > 0)
                {
                    isUCTaken = true;
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                connection.Close();
            }


            return isUCTaken;
        }

        private void chkBoxSPwd_CheckedChanged(object sender, EventArgs e)
        {
            txtBoxPass.UseSystemPasswordChar = false;
            txtBoxConfPass.UseSystemPasswordChar = false;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void registerPage_Load(object sender, EventArgs e)
        {

        }

        private void txtBoxEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lblUser_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxlastName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBoxfirstName_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblText_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxConfPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void rbtnCust_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbtnAdmin_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
